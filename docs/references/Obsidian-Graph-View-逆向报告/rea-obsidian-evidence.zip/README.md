# Obsidian Graph View evidence

Target: local Obsidian application ASAR 1.14.4, examined on 2026-10-26.

This archive contains the original REA records, an agent-authored index, source-analysis notes, and isolated probes. It does not include the application ASAR or the user's notes. The ZIP is a delivery archive, not REA's own evidence-bundle wire format.

- `rea-obsidian-application.json`: unmodified complete CLI analysis record.
- `rea-graph-worker-trace.json`: unmodified complete CLI trace record.
- `evidence-summary.json`: compact human/agent index; this is not an original REA record.
- `graph-verification.json`, `sim-verification.json`: isolated probe results.
- `worker-analysis.md`, `official-sources.md`: detailed supporting notes.
- `prepare-probes.cjs`, `probe-graph.cjs`, `probe-sim.cjs`: reproducible checks.
- `SHA256SUMS.json`: hashes of the other archive members.

Run the probes from the extracted archive directory with the already installed Node and REA package. Preparation reads the ASAR and writes only extracted source copies and a method index beside these scripts. Hash checks require the exact analyzed app.js and sim.js version.

```powershell
node .\prepare-probes.cjs 'C:\Users\donq\AppData\Roaming\obsidian\obsidian-1.14.4.asar' 'C:\Users\donq\AppData\Local\npm-cache\_npx\a1722018f28f9df2\node_modules\rea-agents'
node .\probe-graph.cjs
node .\probe-sim.cjs
```

Both probes use actual shipped code with synthetic inputs. They do not launch the full Obsidian app, inspect note content, exercise a GPU, or reproduce true cross-thread scheduling/structured cloning.

The original REA analysis was run with:

```powershell
node 'C:\Users\donq\AppData\Local\npm-cache\_npx\a1722018f28f9df2\node_modules\rea-agents\scripts\rea.mjs' analyze-javascript-application 'C:\Users\donq\AppData\Roaming\obsidian\obsidian-1.14.4.asar' --source-path package.json --source-path app.js --source-path sim.js --source-path index.html --max-heap-mb 2048 --analysis-timeout-ms 180000 --format json
```

To repeat the trace, save that complete JSON as `rea-obsidian-application.json`, create a JSON file with the following structure, and pass its path to `trace-application-feature --format json`. Replace the placeholder application with the full original record, not its compact index.

```json
{
  "application": "REPLACE WITH COMPLETE ORIGINAL EVIDENCE OBJECT",
  "seed": {
    "kind": "node-id",
    "value": "jag_node_8c9d0118b5edb4942a36f825b7244e05e2805079e176432350cef6a57bf5d077"
  },
  "direction": "outgoing"
}
```

The trace found the Worker syntax node but no outgoing edges. Source coverage remains partial. The complete architecture in the report also uses manual source inspection and isolated execution; it is not an automatic REA trace result.

Paths beginning `work/` in supporting notes refer to the investigation scratch directory. The matching scripts and notes are included here by filename. `prepare-probes.cjs` regenerates the extracted files in `extracted/`.
