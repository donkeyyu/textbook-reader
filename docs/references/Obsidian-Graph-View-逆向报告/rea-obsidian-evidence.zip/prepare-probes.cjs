// Usage: node prepare-probes.cjs <Obsidian ASAR> <installed rea-agents directory>
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { createRequire } = require('node:module');
const [archivePath, reaPath] = process.argv.slice(2);
if (!archivePath || !reaPath) throw Error('Provide the ASAR path and installed rea-agents directory.');
const req = createRequire(path.resolve(reaPath, 'package.json'));
const asar = req('@electron/asar');
const parser = req('@babel/parser');
const expected = { 'app.js': '958ce57fe22f87fdf121546e46dfccd9c8ee971ce3fd8f801d60d4ece39a2df9', 'sim.js': '549be2f69710af360d521c92b80c83718f673594d3dc2255a65e251199eee25d' };
const extracted = path.join(__dirname, 'extracted');
fs.mkdirSync(extracted, { recursive: true });
for (const [file, digest] of Object.entries(expected)) {
  const bytes = asar.extractFile(path.resolve(archivePath), file);
  assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'), digest, `${file}: probes require the analyzed 1.14.4 bytes`);
  fs.writeFileSync(path.join(extracted, file), bytes);
}
const source = fs.readFileSync(path.join(extracted, 'app.js'), 'utf8');
const ast = parser.parse(source, { sourceType: 'unambiguous' });
const methods = [];
function walk(node) {
  if (!node || typeof node !== 'object') return;
  if (node.type === 'AssignmentExpression' && node.left.type === 'MemberExpression' && node.left.object.type === 'MemberExpression' && node.left.object.property.name === 'prototype' && ((node.start > 2379000 && node.start < 2402500) || (node.start > 2721980 && node.start < 2749500))) {
    methods.push({ name: source.slice(node.left.start, node.left.end), start: node.start, end: node.end, code: source.slice(node.right.start, node.right.end) });
  }
  for (const [key, value] of Object.entries(node)) {
    if (key === 'comments' || key === 'tokens') continue;
    if (Array.isArray(value)) value.forEach(walk);
    else if (value && typeof value === 'object') walk(value);
  }
}
walk(ast);
assert.ok(methods.some(m => m.start === 2733103), 'Graph data builder must be present.');
fs.writeFileSync(path.join(__dirname, 'graph-methods.json'), JSON.stringify(methods, null, 2));
console.log(JSON.stringify({ extracted: Object.keys(expected), methods: methods.length, outputDirectory: extracted }));
