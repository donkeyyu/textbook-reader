# Obsidian Graph View：官方资料核对

核对日期：2026-10-26。此文件只记录公开的一手资料，供本机逆向分析交叉验证。

## 可确认的产品行为

Graph View 是核心插件。圆点代表笔记，线代表内部链接；被更多节点引用的笔记会变大。悬停可突出连接，单击可打开笔记。图支持缩放和平移。[官方 Graph View 帮助](https://obsidian.md/help/plugins/graph)

筛选覆盖搜索、标签、附件、未创建的目标和孤立笔记。Groups 按搜索条件着色。显示设置包含箭头、文字淡出、节点大小和线宽。[官方 Graph View 帮助](https://obsidian.md/help/plugins/graph)

四项力设置是 Center force、Repel force、Link force、Link distance。它们分别控制聚拢、排斥、连线拉力和连线长度。Local Graph 从当前笔记逐层显示相连笔记，深度可调。[官方 Graph View 帮助](https://obsidian.md/help/plugins/graph)

这些说明可用来核验行为，但没有指定绘图引擎、力算法库、线程模型或实际公式。

## 可确认的公共数据接口

以下固定到官方 `obsidian-api` 提交 `9abd9605ce081383674aae1ed111c456edde0688`：

| 接口 | 官方定义支持的结论 | 来源 |
|---|---|---|
| `MetadataCache.resolvedLinks` | 源文件路径 → 目标文件路径 → 链接次数；路径是 vault 内的 `TFile.path`。 | [obsidian.d.ts L6495](https://github.com/obsidianmd/obsidian-api/blob/9abd9605ce081383674aae1ed111c456edde0688/obsidian.d.ts#L6495-L6506) |
| `MetadataCache.unresolvedLinks` | 源文件 → 未解析的目标 → 次数。 | [obsidian.d.ts L6501](https://github.com/obsidianmd/obsidian-api/blob/9abd9605ce081383674aae1ed111c456edde0688/obsidian.d.ts#L6501-L6506) |
| `getFirstLinkpathDest(linkpath, sourcePath)` | 根据源路径解析目标，找不到时返回 `null`。 | [obsidian.d.ts L6448](https://github.com/obsidianmd/obsidian-api/blob/9abd9605ce081383674aae1ed111c456edde0688/obsidian.d.ts#L6448-L6460) |
| `changed`、`resolve`、`resolved` | 分别对应缓存更新、单文件链接解析、全部链接解析完成；改名需另监听 Vault 的 `rename`。 | [obsidian.d.ts L6508](https://github.com/obsidianmd/obsidian-api/blob/9abd9605ce081383674aae1ed111c456edde0688/obsidian.d.ts#L6508-L6533) |

“可用这些公共接口构建图数据”是实现建议。它本身不能证明核心 Graph View 实际使用了哪条调用链，仍须检查本机代码。

## 版本与证据边界

该提交的 API 包版本是 `1.14.4`，它不是本机安装版本的证明。[官方 package.json](https://github.com/obsidianmd/obsidian-api/blob/9abd9605ce081383674aae1ed111c456edde0688/package.json#L1-L4)

对该提交的完整 `obsidian.d.ts` 做精确文本检索，未找到 `GraphView` 或 `GraphRenderer`。这只说明这两个名字未在此公共类型文件出现，不能据此断言应用没有这些内部类。[完整官方类型文件](https://github.com/obsidianmd/obsidian-api/blob/9abd9605ce081383674aae1ed111c456edde0688/obsidian.d.ts)

公开帮助没有给出 PixiJS、D3、WebGL、Worker、Barnes–Hut 等实现证据。本机分析若发现这些机制，应以安装包版本、文件、函数和实际调用为依据。

检索时 `master` 网页缓存与 GitHub 实时内容的行号不同。本文件引用固定提交，以免复查时错位。
