# Obsidian Graph Worker：sim.js 证据分析

本记录分析本机提取的 `work/extracted/sim.js`。使用普通源码检查、WASM 指令读取和隔离 Node VM 探针；没有调用新的 REA 分析，也没有运行完整 Obsidian UI。

## 文件身份与复查方式

- `sim.js`：17,693 字节；SHA-256 `549be2f69710af360d521c92b80c83718f673594d3dc2255a65e251199eee25d`。
- 本文件全是 ASCII。下表的偏移均从 0 开始，原始字符偏移与 UTF-8 字节偏移相同。它们不是格式化后的行号。
- 内嵌 WASM：3,322 字节；SHA-256 `b01b7421301b6d70e16319f367863c623a8336b250868a048935800cc8bf575d`。
- 可复查探针：`node work/probe-sim.cjs`。保存的结果为 `work/sim-verification.json`。
- 探针使用同步、有限次数的假定时器和合成图数据。它记录发送时的内容与 transfer list；不模拟浏览器的实际结构化克隆、内存转移或跨线程竞争。

| 原文件短定位串 | 字符偏移 | UTF-8 字节偏移 | 所支持的事实 |
|---|---:|---:|---|
| `var Q=1` | 5240 | 5240 | alpha、冷却与默认力常量 |
| `self.onmessage` | 5329 | 5329 | worker 输入协议 |
| `var f=t.forceNode` | 5802 | 5802 | 固定节点的位置 |
| `var C=t.forces` | 5858 | 5858 | 力参数赋值 |
| `void 0!==t.alpha` | 6070 | 6070 | alpha 只允许升高；run 的触发条件 |
| `K=function` | 6200 | 6200 | WASM 优先，异常时回退 |
| `var A=13*M.length` | 11006 | 11006 | WASM 内存预算 |
| `new Int32Array` | 11166 | 11166 | 边数据开始于 20N 字节 |
| `n.init(0,M.length,G.length)` | 11391 | 11391 | 图变化后重建 WASM 输入 |
| `n.simulate` | 11419 | 11419 | WASM 力参数顺序 |
| `n.complete` | 11467 | 11467 | 积分、阻尼，再应用固定坐标 |
| `q=function` | 12799 | 12799 | fallback 链接力 |
| `R=function` | 14239 | 14239 | fallback 四叉树排斥力 |
| `k=function` | 15539 | 15539 | fallback 碰撞力 |
| `Using fallback d3 simulator` | 16601 | 16601 | fallback 自身给出的名称 |
| `w&&` | 16738 | 16738 | fallback 力设置刷新门控 |
| `if(self.SharedArrayBuffer)` | 17167 | 17167 | SAB 功能探测 |
| `var Z=null` | 17283 | 17283 | SAB 坐标缓冲与版本 |
| `function W()` | 17574 | 17574 | 单次 tick 与冷却 |
| `function P()` | 17652 | 17652 | 去重后的 setTimeout 调度 |

可用以下短脚本按原偏移复查，而不用复制整段程序：

```js
const fs = require('node:fs');
const s = fs.readFileSync('work/extracted/sim.js', 'utf8');
const i = s.indexOf('n.simulate');
console.log({ char: i, byte: Buffer.byteLength(s.slice(0, i)) });
console.log(s.slice(i, i + 100));
```

## 输入协议

输入是 `self.onmessage` 接收的 `event.data`，字段可组合在同一条消息中，按下列顺序处理。

| 字段 | 形状 | 本文件的处理 |
|---|---|---|
| `nodes` | `{ [id]: [x,y] \| null }` | 作为完整节点集合。删除缺席 ID，保留已有对象及其速度、固定坐标，新增对象从位置和速度 0 开始。非空坐标覆盖 x/y；`null` 保留现有坐标。最后重排 index。 |
| `links` | `[[sourceId,targetId], ...]` | 替换边列表。只有两端都在节点表中的边会加入。重复边没有在 worker 中去重。 |
| `forceNode` | `{ id, x, y }` | 给已有节点设置 fx/fy。数值表示固定位置；`null` 或缺省坐标解除相应轴的固定。 |
| `forces` | `{ centerStrength?, linkStrength?, linkDistance?, repelStrength? }` | 更新四项内部参数。repel 内部取负；若输入绝对值小于 1，内部强制为 -1。 |
| `alpha` | number | 只有输入大于当前 alpha 才更新。不能借此降低 alpha。 |
| `alphaTarget` | number | 直接更新目标 alpha。 |
| `run` | 任意非 `undefined` 值 | 调用调度器。源码没有按真假判断，`run:false` 也会启动。 |

仅发送 nodes、links 或 alpha 不会启动已停止的调度器。重复 run 不会产生并行定时器。本文件也没有单独的 stop 指令。若只更新节点集合而不更新 links，旧边引用不会在这条分支自动重建；调用端怎样组合消息须结合 app.js 确认。

## 主路径：WASM 布局

先检查 WebAssembly 对象与 instantiate 函数，再同步建立 `WebAssembly.Module` 和 `WebAssembly.Instance`。这一流程包在 try/catch 内；失败则返回 null 并选择 JavaScript fallback。它没有在此从网络下载 WASM。

WASM exports 为 `memory`、`memset`、`init`、`complete`、`visitCharge`、`visitCollide`、`manyBody`、`simulate`。导出名与加载方式是直接源码证据，不代表原始 C/C++ 源文件或编译器已经确认。

N 为节点数，E 为边数。JS 包装层按 `52N + 12E + 1024` 字节检查容量，不足时按 65,536 字节页增长。初始 memory 为 65,536 字节，探针已验证。

节点区域每节点 20 字节：五个 float32 为 x、y、vx、vy、degree。边区域从 20N 字节处开始，每边 12 字节：source index int32、target index int32、bias float32。JS 先写前四个节点值及两个边索引；`init` 填充 degree 和 bias。探针对 A—B、A—C 验得 degree 为 2/1/1，两个 bias 均约为 2/3。

只有节点或边变化时，包装层才把 JS 对象状态重新写入该内存并调用 init。每 tick 的核心调用参数为：

```text
simulate(0, N, E, alpha, center, linkStrength, linkDistance, -repel, 0.9, 0.5)
complete(0, N, 0.6)
```

随后将 fx/fy 固定值写回坐标、把对应速度清零，再把 WASM 位置和速度读回 JS 节点对象。输出只发送位置。

对内嵌 WASM 的 code section 做了基础 opcode 读取。以下是已支持的数学结论，偏移指解码后的 WASM 二进制，不是 sim.js 文本：

- simulate 的 function index 为 6。二进制 2937–3002：中心力分别从 vx、vy 减去 `alpha * center * x/y`。
- 3039–3266：链接力使用预测位置 x+vx/y+vy，强度按两端较小 degree 的倒数缩放，位移按 init 生成的 source degree / 两端 degree 总和分配。这与 fallback 的主要链接力结构一致。
- 二进制 3085、3141 的 float32 常量约为 0.1，用于链接 dx 或 dy 恰为 0 的情况。fallback 在此使用微小伪随机扰动；两者并不完全相同。
- 3304–3319：simulate 将 `alpha * repel`、0.9、0.5 交给 manyBody。0.9 和 0.5 的语义结合 JS fallback 的 theta/碰撞强度可作对应理解；此记录不据此声称两套空间结构和退化情况处理完全相同。

未完整还原 WASM manyBody / visitCharge / visitCollide 的全部实现。因此不会把 fallback 的全部碰撞半径、软化方式或四叉树结构直接说成 WASM 的精确实现。

## JavaScript fallback

源码明确打印 `Using fallback d3 simulator`，内联了 D3 风格的节点力和四叉树代码。但没有在此找到可确认其精确 npm 版本的版本标签。

按调用顺序施加：x 中心力、y 中心力、链接力、排斥力、碰撞力，再积分。

默认参数：中心强度 0.1，链接距离 250，排斥强度 -1000，排斥最小距离 30，Barnes–Hut theta 0.9，碰撞半径 60，碰撞强度 0.5，一次迭代。链接基础强度为 `1 / min(degree(source), degree(target))`，bias 为 `degree(source)/(degree(source)+degree(target))`。

主要公式：

```text
center: v += -position * centerStrength * alpha
link: d = predictedTarget - predictedSource
      k = (length(d)-linkDistance)/length(d) * alpha * linkStrength/minDegree
      target.v -= d*k*bias; source.v += d*k*(1-bias)
integrate: v *= 0.6; position += v
```

排斥力按四叉树访问；可接受整个 cell 时，以聚合强度近似。距离平方低于 900 时，分母软化为 `sqrt(900 * distanceSquared)`。碰撞基于预测位置，两个半径之和为 120；它不乘 alpha。重合情况的扰动来自种子初始为 1 的 LCG：`seed=(1664525*seed+1013904223) mod 2^32`，扰动值为 `1e-6*(random-0.5)`。

此版本有一个值得保留的实现细节：外部 forces 会更新 c/E/v/x，但 fallback 的力对象刷新块受 `w&&` 控制。完整 sim.js 中 w 只初始化为 false，并在刷新块内清为 false；未找到置 true 的代码。隔离探针中，同一图改变四项 forces 后，连续八帧 fallback 坐标逐项完全相等；WASM 坐标则明显改变。因此本文件中的 fallback 会保留默认力设置。这是对这份文件的结论，尚未在完整 UI 中强制触发 fallback。

同一非重叠三节点图的默认第一帧，两引擎非常接近，但有约 1.5e-5 的 float32 差异。不能据此将两引擎当成完全相同的数值实现。

## 调度与冷却

alpha 初始为 1，target 初始为 0。每 tick 先更新：

```text
decay = 1 - 0.001^(1/300) = 0.02276277904418933
alpha += (target - alpha) * decay
```

使用 setTimeout，间隔 `1000/60` ms；这是调度目标，不能当作真实 UI 保证帧率。tick 入口若 alpha 不大于 0.001 就停止。入口符合条件时先排下一次 tick，再检查节点数、计算和发送。

探针中两引擎均在默认冷却时发送 300 帧，第 301 次 timer 回调停止。约等于目标调度下 5 秒的计算过程，但真实耗时受线程负载影响。alphaTarget 保持在阈值以上会维持运行。

空图分支在降低 alpha 之前直接返回，且已排下一次 timer。探针用十次有界回调确认：没有帧输出，仍有下一次 timer。该事实只描述 worker 的独立行为；调用端是否终止 worker 须看 app.js 生命周期。

## 输出协议与 SharedArrayBuffer

两种输出都以 id 数组确定坐标顺序。坐标按 `[x0,y0,x1,y1,...]` 的 float32 交错存储，没有在每帧重复传递边或速度。

若 self.SharedArrayBuffer 存在，会先试建 1 字节 SAB，并发送 `{ignore:true,shared:probeBuffer}`。构造或发送抛错则采用普通 ArrayBuffer。

| 路径 | 消息 | 缓冲布局 | 生命周期 |
|---|---|---|---|
| SAB | `{id,buffer,v}` | 前 8N 字节为坐标；末尾 4 字节为 Uint32 版本 | 字节数不变就复用，节点数变化才换缓冲；没有 transfer list。 |
| ArrayBuffer | `{id,buffer}` | 8N 字节坐标 | 每帧新建，并把 buffer 放入 transfer list。 |

SAB 写完坐标后，worker 读取尾版本为 v，执行尾版本加一，再发送携带旧 v 的消息。探针第 0 帧消息 v=0、发送时尾版本=1；第 1 帧消息 v=1、尾版本=2。生产端没有在此使用 Atomics。消费端如何判新旧、何时复制或绘制，须由 app.js 核实。

## 已验证与尚未覆盖

`work/probe-sim.cjs` 全部断言通过：两引擎的输入更新、固定/释放坐标、未知边过滤、run:false、timer 去重、300 帧冷却、alpha 单独不启动、SAB 探测/复用/版本、ArrayBuffer transfer list、WASM degree/bias、WASM 参数应用，以及 fallback 参数未生效。

尚未覆盖完整 Obsidian renderer、真实 worker 通信和 SAB 竞态、UI 帧率、超大图容量、WASM 内部全部空间索引细节。这里没有修改安装包或工作笔记。
