// Isolated worker tests. This does not run the Obsidian UI.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const sourcePath = require('node:path').join(__dirname, 'extracted', 'sim.js');
const source = fs.readFileSync(sourcePath, 'utf8');

function worker({ wasm = true, shared = false } = {}) {
  const queue = [], frames = [], messages = [], logs = [], calls = [];
  let nextTimer = 0, lastMemory;
  const wasmApi = wasm ? {
    instantiate: WebAssembly.instantiate,
    Module: WebAssembly.Module,
    Instance: function (module, imports) {
      const original = new WebAssembly.Instance(module, imports).exports;
      lastMemory = original.memory;
      return { exports: { ...original,
        simulate(...args) { calls.push({ fn: 'simulate', args }); return original.simulate(...args); },
        complete(...args) { calls.push({ fn: 'complete', args }); return original.complete(...args); },
        init(...args) { calls.push({ fn: 'init', args }); return original.init(...args); }
      } };
    }
  } : undefined;
  const context = {
    WebAssembly: wasmApi,
    SharedArrayBuffer: shared ? SharedArrayBuffer : undefined,
    atob,
    console: { log: (...args) => logs.push(args) },
    setTimeout(callback, delay) { const id = ++nextTimer; queue.push({ id, callback, delay }); return id; },
    postMessage(message, transfers) {
      messages.push({ message, transfers });
      if (message.buffer) frames.push({
        ids: Array.from(message.id),
        coords: Array.from(new Float32Array(message.buffer, 0, message.id.length * 2)),
        bytes: message.buffer.byteLength,
        version: message.v,
        trailingVersion: shared ? new Uint32Array(message.buffer, message.buffer.byteLength - 4, 1)[0] : null,
        reference: message.buffer,
        transfers: transfers?.length || 0
      });
    }
  };
  context.self = context;
  vm.runInNewContext(source, context, { filename: 'sim.js', timeout: 5000 });
  return {
    queue, frames, messages, logs, calls,
    get memory() { return lastMemory; },
    send(data) { context.onmessage({ data }); },
    step(count = 1) { for (let i = 0; i < count; i++) { const timer = queue.shift(); if (!timer) break; timer.callback(); } }
  };
}

const graph = { nodes: { A: [-100, 30], B: [120, -20], C: [40, 170] }, links: [['A', 'B'], ['A', 'C']] };
function simulate(options, forces, ticks = 8) {
  const w = worker(options);
  w.send({ ...graph, ...(forces ? { forces } : {}), run: true });
  w.step(ticks);
  return w;
}
const results = {};

for (const wasm of [true, false]) {
  const w = worker({ wasm });
  w.send({ ...graph });
  assert.equal(w.queue.length, 0, 'nodes/links alone must not start timers');
  w.send({ run: false });
  assert.equal(w.queue.length, 1, 'run:false still starts the worker');
  assert.equal(w.queue[0].delay, 1000 / 60);
  w.send({ run: true });
  assert.equal(w.queue.length, 1, 'repeated run must not duplicate timers');
  w.send({ forceNode: { id: 'A', x: 50, y: -75 } });
  w.step();
  assert.deepEqual(w.frames[0].coords.slice(0, 2), [50, -75]);
  assert.equal(w.frames[0].bytes, 24);
  assert.equal(w.frames[0].transfers, 1);
  w.send({ forceNode: { id: 'A', x: null, y: null }, alpha: 1, nodes: { A: null, D: [5, 6] }, links: [['A', 'D'], ['A', 'missing']] });
  w.step();
  assert.deepEqual(w.frames[1].ids, ['A', 'D']);
  assert.equal(w.frames[1].bytes, 16);
  assert.notDeepEqual(w.frames[1].coords.slice(0, 2), [50, -75], 'released node moves again');
  if (wasm) assert.deepEqual(w.calls.filter(c => c.fn === 'init').at(-1).args, [0, 2, 1], 'unknown-endpoint edge is omitted');
  results[wasm ? 'wasm_protocol' : 'fallback_protocol'] = { ids: w.frames[1].ids, firstPinned: w.frames[0].coords.slice(0, 2) };
}

const forces = { centerStrength: 0.9, linkStrength: 0.05, linkDistance: 10, repelStrength: 2 };
const fallbackDefault = simulate({ wasm: false });
const fallbackChanged = simulate({ wasm: false }, forces);
assert.deepEqual(fallbackDefault.frames.map(f => f.coords), fallbackChanged.frames.map(f => f.coords), 'fallback ignores force settings in this bundle');
const wasmDefault = simulate({ wasm: true });
const wasmChanged = simulate({ wasm: true }, forces);
assert.notDeepEqual(wasmDefault.frames.map(f => f.coords), wasmChanged.frames.map(f => f.coords));
assert.deepEqual(wasmChanged.calls.find(c => c.fn === 'simulate').args.slice(4), [0.9, 0.05, 10, -2, 0.9, 0.5]);
const clampedRepel = simulate({ wasm: true }, { repelStrength: 0 });
assert.equal(clampedRepel.calls.find(c => c.fn === 'simulate').args[7], -1);
results.force_settings = { fallbackIgnored: true, wasmApplied: true, fallbackDefaultFrame1: fallbackDefault.frames[0].coords, wasmDefaultFrame1: wasmDefault.frames[0].coords, wasmChangedFrame1: wasmChanged.frames[0].coords };

for (const wasm of [true, false]) {
  const w = worker({ wasm });
  w.send({ nodes: { A: [20, 30] }, links: [], run: true });
  let callbacks = 0;
  while (w.queue.length && callbacks < 1000) { w.step(); callbacks++; }
  assert.equal(w.queue.length, 0);
  assert.equal(w.frames.length, 300);
  w.send({ alpha: 1 });
  assert.equal(w.queue.length, 0, 'alpha alone does not restart a stopped timer');
  w.send({ run: true });
  w.step();
  assert.equal(w.frames.length, 301);
  results[wasm ? 'wasm_cooling' : 'fallback_cooling'] = { callbacksToStop: callbacks, framesToStop: 300 };
}
const empty = worker();
empty.send({ nodes: {}, links: [], run: true });
empty.step(10);
assert.equal(empty.frames.length, 0);
assert.equal(empty.queue.length, 1);
results.empty = { boundedCallbacks: 10, noFrames: true, timerStillPending: true };

const shared = worker({ shared: true });
assert.equal(shared.messages[0].message.ignore, true);
assert.equal(shared.messages[0].message.shared.byteLength, 1);
shared.send({ ...graph, run: true });
shared.step(2);
assert.equal(shared.frames[0].bytes, 28);
assert.equal(shared.frames[0].version, 0);
assert.equal(shared.frames[0].trailingVersion, 1);
assert.equal(shared.frames[1].version, 1);
assert.equal(shared.frames[1].trailingVersion, 2);
assert.equal(shared.frames[0].reference, shared.frames[1].reference);
assert.equal(shared.frames[0].transfers, 0);
results.shared = { initialProbeBytes: 1, frameBytes: 28, versions: shared.frames.map(f => f.version), tailVersionsAtSend: shared.frames.map(f => f.trailingVersion), reusesBuffer: true };

const wasmBytes = Buffer.from(source.match(/"(AGFzb[^"\n]+)"/)[1], 'base64');
const wasmExports = new WebAssembly.Instance(new WebAssembly.Module(wasmBytes), { env: { abort() {}, clog() {}, flog() {} } }).exports;
const floats = new Float32Array(wasmExports.memory.buffer), ints = new Int32Array(wasmExports.memory.buffer);
const n = 3, edgeBase = n * 5;
for (let i = 0; i < n; i++) { floats[i * 5] = i * 10; floats[i * 5 + 1] = 0; }
ints[edgeBase] = 0; ints[edgeBase + 1] = 1;
ints[edgeBase + 3] = 0; ints[edgeBase + 4] = 2;
wasmExports.init(0, 3, 2);
assert.deepEqual([floats[4], floats[9], floats[14]], [2, 1, 1]);
assert.ok(Math.abs(floats[edgeBase + 2] - 2 / 3) < 1e-6);
results.wasm_memory = { wasmBytes: wasmBytes.length, exports: Object.keys(wasmExports), degreeByNode: [floats[4], floats[9], floats[14]], edgeBias: [floats[edgeBase + 2], floats[edgeBase + 5]], initialMemoryBytes: wasmExports.memory.buffer.byteLength };

const needles = ['var Q=1', 'self.onmessage', 'var f=t.forceNode', 'var C=t.forces', 'void 0!==t.alpha', 'K=function', 'var A=13*M.length', 'new Int32Array', 'n.init(0,M.length,G.length)', 'n.simulate', 'n.complete', 'q=function', 'R=function', 'k=function', 'w&&', 'Using fallback d3 simulator', 'if(self.SharedArrayBuffer)', 'var Z=null', 'function W()', 'function P()'];
results.evidence = needles.map(needle => { const charOffset = source.indexOf(needle); assert.notEqual(charOffset, -1); return { needle, charOffset, utf8ByteOffset: Buffer.byteLength(source.slice(0, charOffset)) }; });
console.log(JSON.stringify({ sourcePath, sha256: crypto.createHash('sha256').update(source).digest('hex'), charLength: source.length, byteLength: Buffer.byteLength(source), scope: 'isolated Node vm worker execution; no Obsidian UI', results }, null, 2));
