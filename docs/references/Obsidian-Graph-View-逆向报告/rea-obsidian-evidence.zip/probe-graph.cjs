// Tests shipped functions with synthetic metadata and renderer objects; no Obsidian UI.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, 'extracted/app.js'), 'utf8');
assert.equal(crypto.createHash('sha256').update(source).digest('hex'), '958ce57fe22f87fdf121546e46dfccd9c8ee971ce3fd8f801d60d4ece39a2df9');
const methods = JSON.parse(fs.readFileSync(path.join(__dirname, 'graph-methods.json')));
const method = start => methods.find(m => m.start === start).code;
const helperStart = source.indexOf('function gZ(');
const helperEnd = source.indexOf('var yZ=', helperStart);
const localStart = source.indexOf('function SZ(');
const localEnd = source.indexOf('var xZ=', localStart);
const context = vm.createContext({
  O2: class LocalGraph {},
  isBoolean: value => typeof value === 'boolean',
  Lx: () => false, // Synthetic fixtures contain only Markdown notes.
  _m: cache => cache?.tags || [], // Metadata tag extraction is outside this test.
  Math,
});
vm.runInContext(`${source.slice(helperStart, helperEnd)};var yZ={tag:true};${source.slice(localStart, localEnd)};`, context);
const render = vm.runInContext(`(${method(2733103)})`, context);
const local = vm.runInContext('SZ', context);
const defaults = { showAttachments: false, hideUnresolved: false, showTags: false, showOrphans: true, localFile: null, localJumps: 1, localInterlinks: false, localForelinks: true, localBacklinks: true };
const metadataCache = {
  resolvedLinks: { 'A.md': { 'B.md': 9 }, 'B.md': { 'A.md': 2, 'C.md': 1 }, 'C.md': {}, 'Orphan.md': {} },
  unresolvedLinks: { 'A.md': { Missing: 3 } },
  getCachedFiles: () => ['A.md', 'B.md', 'C.md', 'Orphan.md'],
  getTags: () => ({ '#Topic': 1 }),
  getCache: name => ({ tags: name === 'A.md' ? ['#topic'] : [] }),
  isUserIgnored: () => false,
  vault: {},
};
function graph(overrides = {}) {
  let output;
  render.call({ app: { metadataCache }, view: {}, renderer: { setData: value => output = value }, options: { ...defaults, ...overrides }, searchQueries: null, fileFilter: {}, progression: 0 });
  return JSON.parse(JSON.stringify(output));
}
const full = graph();
assert.equal(full.nodes['A.md'].links['B.md'], true);
assert.equal(Object.keys(full.nodes['A.md'].links).length, 2);
assert.equal(full.nodes.Missing.type, 'unresolved');
assert.ok(!graph({ hideUnresolved: true }).nodes.Missing);
assert.ok(!graph({ showOrphans: false }).nodes['Orphan.md']);
const tagged = graph({ showTags: true });
assert.equal(tagged.nodes['#Topic'].type, 'tag');
assert.equal(tagged.nodes['A.md'].links['#Topic'], true);
const local1 = JSON.parse(JSON.stringify(local(full, { ...defaults, localFile: 'A.md' })));
assert.deepEqual(Object.keys(local1.nodes).sort(), ['A.md', 'B.md', 'Missing']);
assert.equal(local1.weights['A.md'], 30);
assert.equal(local1.weights['B.md'], 0);
const local2 = JSON.parse(JSON.stringify(local(full, { ...defaults, localFile: 'A.md', localJumps: 2 })));
assert.ok(local2.nodes['C.md']);
assert.equal(local2.weights['B.md'], 15);
assert.equal(local2.weights['C.md'], 0);
const neighborFixture = structuredClone(full);
neighborFixture.nodes['B.md'].links.Missing = true;
const noInterlinks = JSON.parse(JSON.stringify(local(neighborFixture, { ...defaults, localFile: 'A.md' })));
assert.ok(!noInterlinks.nodes['B.md'].links.Missing);
const interlinks = JSON.parse(JSON.stringify(local(neighborFixture, { ...defaults, localFile: 'A.md', localInterlinks: true })));
assert.equal(interlinks.nodes['B.md'].links.Missing, true);

vm.runInContext(`Array.prototype.remove=function(x){const i=this.indexOf(x);if(i>=0)this.splice(i,1)};
function kZ(renderer,id,type){Object.assign(this,{renderer,id,type,x:null,y:null,forward:{},reverse:{},weight:0,color:null});}
kZ.prototype.getRelated=${method(2384404)};
kZ.prototype.clearGraphics=function(){};
function CZ(renderer,source,target){Object.assign(this,{renderer,source,target});}
CZ.prototype.clearGraphics=function(){};
`, context);
const setData = vm.runInContext(`(${method(2397403)})`, context);
const renderer = vm.runInContext('({nodes:[],links:[],nodeLookup:{}})', context);
const messages = [];
renderer.worker = { postMessage: message => messages.push(JSON.parse(JSON.stringify(message))) };
renderer.changed = () => {};
setData.call(renderer, { nodes: { 'A.md': { type: '', links: { 'B.md': true } }, 'B.md': { type: '', links: { 'A.md': true } } } });
assert.equal(renderer.nodeLookup['A.md'].weight, 2);
renderer.nodeLookup['A.md'].x = 71;
renderer.nodeLookup['B.md'].y = 29;
setData.call(renderer, { nodes: { 'A.md': { type: '', links: { 'B.md': true } }, 'B.md': { type: '', links: { 'A.md': true } } } });
assert.equal(messages.length, 1, 'unchanged topology must not restart simulation');
setData.call(renderer, { nodes: { 'A.md': { type: '', links: {} } } });
assert.equal(renderer.nodeLookup['A.md'].x, 71);
assert.equal(renderer.nodes.length, 1);
assert.equal(renderer.links.length, 0);
assert.equal(messages[1].nodes['A.md'], false);
assert.equal(renderer.nodeLookup['A.md'].weight, 0);
const getSize = vm.runInContext(`(${method(2384227)})`, context);
assert.equal(getSize.call({ renderer: { fNodeSizeMult: 1 }, weight: 0 }), 8);
assert.equal(getSize.call({ renderer: { fNodeSizeMult: 1 }, weight: 8 }), 9);
assert.equal(getSize.call({ renderer: { fNodeSizeMult: 1 }, weight: 9999 }), 30);

console.log(JSON.stringify({ scope: 'Shipped app.js functions in isolated Node vm; synthetic metadata; UI, search parser and tag parser excluded', source_sha256: crypto.createHash('sha256').update(source).digest('hex'), checks: ['link-count-deduplication','unresolved-toggle','orphan-filter','tag-node-case','local-depth-and-weights','local-interlinks','reciprocal-degree','incremental-node-reuse','unchanged-topology-idle','node-removal','radius-formula'], passed: true, localDepth1: local1, workerUpdateAfterRemoval: messages[1] }, null, 2));
